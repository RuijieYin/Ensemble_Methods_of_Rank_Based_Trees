#' Prediction function for blc
#'
#'
#'
#'
#'
#' @return
#' @export
#'
#' @examples
#' predict(blc$model, liver_test_x)
predict.blc = function(object, newdata) {
  NULL
}
