#' Prediction function for rrf
#'
#'
#'
#'
#'
#' @return
#' @export
#'
#' @examples
#' predict(rrf$model, liver_data$liver_test_x)
predict.rrf = function(object, newdata) {
  NULL
}
